## MultiView and Single Item Select

1. Make a new HTML file and add 3 SVG elements to it
2. Load the "data/palmer_penguin_species.tsv"
3. Use the example 2 (scatter_plot) and add 3 plots such that each plot represents:<br>
a. One of species only.<br>
b. X Axis = culmen_length_mm, Y Axis = culmen_depth_mm	and (size of the circle - radius) to be flipper_length_mm<br>
c. Color scale it by the island column.
