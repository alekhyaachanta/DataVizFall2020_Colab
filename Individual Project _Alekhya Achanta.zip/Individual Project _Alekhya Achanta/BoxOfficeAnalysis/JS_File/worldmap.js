/*function plotmap(){
    d3.queue()
        .defer(d3.json, "http://enjalot.github.io/wwsd/data/world/world-110m.geojson")
        .defer(d3.csv, "data/country_budget.csv", function (d) {
            data.set(d.country, +d.sum_budget);
        })
        .await(ready);
}*/


function ready(data) {
    if (error) throw error;
    let svg = d3.select("#map"),
        width = 1000,
        height = 800;
    let topo=data[0];
    let newData=new Set(d3.map(data[1],function (d){
        return d.country, +d.sum_budget
    }));
    let projection = d3.geoNaturalEarth()
        .scale(width / 2 / Math.PI)
        .translate([width / 2, height / 2])
    let path = d3.geoPath()
        .projection(projection);

    //let data = d3.map();
    //console.log(data)
    let colorScale = d3.scaleThreshold()
        .domain([1, 6, 11, 26, 101, 1001])
        .range(d3.schemeBlues[6]);

    let div = d3.select("body").append("div")
        .attr("class", "tooltip")
        .style("opacity", 0);


    let g = svg.append("g")
        .attr("class", "legendThreshold")
        .attr("transform", "translate(20,20)");
    g.append("text")
        .attr("class", "caption")
        .attr("x", 0)
        .attr("y", -6)
        .text("Total Movies");
    svg.append("g")
        .attr("class", "countries")
        .selectAll("path")
        .data(topo.features)
        .enter().append("path")
        .attr("fill", function (d) {
            d.sum_budget = newData.get(d.properties.name) || 0;
            return colorScale(d.sum_budget);
        })
        .attr("d", path)
        .on("mouseover", function (d) {
            div.transition()
                .duration(200)
                .style("opacity", .9);
            div.html(d.properties.name + "<br/>" + d.sum_budget)
                .style("left", (d3.event.pageX) + "px")
                .style("top", (d3.event.pageY - 28) + "px");
        })
        .on("mouseout", function (d) {
            div.transition()
                .duration(500)
                .style("opacity", 0);
        });
}