function scatter(data){
    let margin = {top: 30, right: 30, bottom: 30, left: 30},
        width = 1000 - margin.left - margin.right,
        height = 800 - margin.top - margin.bottom;

// append the svg object to the body of the page
    var svg = d3.selectAll("#scatter")
    let chart=svg.append("g")
        .attr("transform",
            "translate(" + margin.left + "," + margin.top + ")");

//Read the data

        var x = d3.scaleLinear()
            .domain([4,24])
            .range([ 0, width ]);
        svg.append("g")
            .attr("transform", "translate("+margin.left+"," + (height+margin.top) + ")")
            .style('font-size', '18px')
            .call(d3.axisBottom(x));

        // Add Y axis
        var y = d3.scaleLinear()
            .domain([4,24])
            .range([ height, 0]);
        svg.append("g")
            .attr("transform", "translate("+(margin.left)+"," + (margin.top) + ")")
            .call(d3.axisLeft(y))
            .style('font-size', '18px');

    let div = d3.select('body').append("div")
        .attr("class", "tooltip")
        .style("opacity", 0);
        // Add dots
        chart.selectAll("dot")
            .data(data)
            .enter()
            .append("circle")
            .attr("cx", function (d) {return x(d.budget); } )
            .attr("cy", function (d) { return y(d.gross); } )
            .attr("r", 5)
            .style("fill", "#69b3a2")
            .style('opacity','0.6')
            .on('mouseover', function (d, i) {
                d3.select(this).transition()
                    .duration('50')
                    .attr('opacity', '.85')
                div.transition()
                    .duration('50')
                    .style("opacity", 0.8);
                let selection=d3.select(this)
                let arr=[].concat("Budget: "+Math.round(d.budget),"Gross: "+Math.round(d.gross))
                div.html(arr.join('<br/>'))
                    .style("left", (event.pageX + 10) + "px")
                    .style("top", (event.pageY - 15) + "px");
            })
            .on('mouseout', function (d, i) {
                d3.select(this).transition()
                    .duration('250')
                    .attr('opacity', '1')

                div.transition()
                    .duration('250')
                    .style("opacity", 0);
            })
}
